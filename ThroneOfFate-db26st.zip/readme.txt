Installation

Unzip the package you`ve downloaded to a separate folder and run Setup.exe which is included in the package, to install and activate the game.

